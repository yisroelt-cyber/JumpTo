// Shared constants (single source of truth)
// Keep storage caps and UI constraints aligned to prevent silent truncation.
export const MAX_RECENTS = 20;
